package com.ZeLinZhou.service;

import com.ZeLinZhou.model.Account;

public interface Check {
	public abstract boolean isExistedUsers(Account user);// 判断登录用户是否存在

	public abstract boolean isInvalidUserName(Account user);// 判断用户是否已被注册

	public abstract boolean isInvalidPassword(Account user, String confirmedPassword);// 判断注册时密码是否符合要求，且两次输入的密码是否一致
}
