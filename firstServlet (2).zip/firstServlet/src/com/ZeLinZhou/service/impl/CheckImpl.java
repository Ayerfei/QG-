package com.ZeLinZhou.service.impl;

import com.ZeLinZhou.util.Util;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.ZeLinZhou.service.Check;

import com.ZeLinZhou.model.Account;

public class CheckImpl implements Check {
	Connection con = null;
	PreparedStatement ps = null;
	ResultSet rs = null;
	String sql = "SELECT * FROM users WHERE userName=? and password=?;";// 发送SQL语句给数据库
	Util util = new Util();
	boolean existed;

	// 判断登录时用户是否存在以及密码是否正确
	public boolean isExistedUsers(Account user) {
		try {
			existed = false;
			con = Util.getCon();
			ps = (PreparedStatement) con.prepareStatement(sql);
			ps.setString(1, user.getUserName());// 查找userName是否存在，1为SQL语句中的第一个问号
			ps.setString(2, user.getPassword());
			rs = ps.executeQuery();// 在SQL中查询后的结果集对象
			if (rs.next()) {// 如果rs.next()不为null的话，说明已找到
				existed = true;
			} else {
				existed = false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			util.close(ps, con, rs);
		}
		return existed;
	}

	// 判断注册用户是否存在
	public boolean isInvalidUserName(Account user) {
		try {
			existed = false;
			con = Util.getCon();
			ps = (PreparedStatement) con.prepareStatement(sql);
			ps.setString(1, user.getUserName());
			rs = ps.executeQuery();
			if (rs.next()) {
				existed = true;
			} else {
				/*
				 * AccountDaoImpl add = new AccountDaoImpl(); add.addAccount(user);
				 */
				existed = false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			util.close(ps, con, rs);
		}
		return existed;
	}

	// 判断注册时用户密码格式是否正确，以及用户输入的两次密码是否一致
	public boolean isInvalidPassword(Account user, String confirmedPasswd) {// 检查密码格式以及两次输入的密码是否一致
		String password = user.getPassword();
		return password == null || password.length() < 6 || password.length() > 16 || !password.equals(confirmedPasswd);
	}
}
