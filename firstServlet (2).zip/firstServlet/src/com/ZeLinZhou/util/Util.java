package com.ZeLinZhou.util;

import java.sql.DriverManager;
import java.sql.SQLException;
import com.mysql.jdbc.Connection;

public class Util {
	private static String driver = "com.mysql.jdbc.Driver";
	private static String url = "jdbc:mysql://localhost:3306/users";
	private static String user = "root";
	private static String password = "alin15521418797confidence";

	static {
		try {
			Class.forName(driver);
			System.out.println("数据库驱动加载成功");
		} catch (ClassNotFoundException e) {
			System.out.println("数据库驱动加载失败");
			e.printStackTrace();
		}
	}

	// 连接
	public static Connection getCon() throws SQLException {
		Connection con = null;
		con = (Connection) DriverManager.getConnection(url, user, password);
		System.out.println("数据库连接成功");
		return con;
	}

	// 关闭
	public static void close(java.sql.PreparedStatement ps, java.sql.Connection con, java.sql.ResultSet rs) {
		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (ps != null) {
			try {
				ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (con != null) {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}

}