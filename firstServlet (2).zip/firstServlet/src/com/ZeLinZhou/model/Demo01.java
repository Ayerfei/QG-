package com.ZeLinZhou.model;

import com.ZeLinZhou.util.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Demo01 {

	/**
	 * 增加用户
	 * 
	 * @param username
	 * @param password
	 * @return
	 * @throws Exception
	 */
	/*
	 * public static int addUser(String username, String password) throws Exception{
	 * Connection con = Util.getCon(); String sql =
	 * "insert into text values('"+username+"','"+password+"')"; Statement stmt =
	 * con.createStatement(); return 0; }
	 */
	public static void main(String[] args) throws Exception {

		Connection con = Util.getCon();// 获取数据库
		PreparedStatement ps = null;
		SQLException ex = null;
		ResultSet rs = null;
		String username = "Ayfeier";
		String password = "123456";
		try {
			con = Util.getCon();
			ps = (PreparedStatement) con.prepareStatement("insert into users (userName, password) values(?, ?)");
			ps.setString(1, username);// 与SQL语句对应，实现什么功能与关键字有关，此时是插入
			ps.setString(2, password);
			System.out.println(password);
			ps.executeUpdate();// 执行SQL语句
			System.out.println(password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			ex = e;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			Util.close(ps, con, null);
		}
	}
}
