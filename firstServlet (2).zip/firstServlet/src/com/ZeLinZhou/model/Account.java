package com.ZeLinZhou.model;

/**
 * 创建用户类
 * 
 * @author Machenike
 *
 */
public class Account {
	private String userName;// 不让其它类修改，但可以获悉其值
	private String password;

	public Account() {
		this.userName = null;
		this.password = null;
	}

	public Account(String userName, String password) {
		// TODO Auto-generated constructor stub
		this.userName = userName;
		this.password = password;
	}

	public String getUserName() {
		return userName;
	}

	public String getPassword() {
		return password;
	}

}
