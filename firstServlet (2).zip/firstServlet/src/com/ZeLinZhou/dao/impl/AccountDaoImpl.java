package com.ZeLinZhou.dao.impl;

import com.ZeLinZhou.dao.AccountDao;
import com.ZeLinZhou.model.Account;
import com.ZeLinZhou.util.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * 实现AccountDAO接口
 * 
 * @author Mechanic
 *
 */

public class AccountDaoImpl implements AccountDao {
	Connection con = null;
	PreparedStatement ps = null;
	SQLException ex = null;

	public void addAccount(Account account) throws Exception {
		try {
			con = Util.getCon();
			ps = (PreparedStatement) con.prepareStatement("insert into users (userName, password) values(?, ?)");
			ps.setString(1, account.getUserName());// 与SQL语句对应，实现什么功能与关键字有关，此时是插入
			ps.setString(2, account.getPassword());
			// System.out.println(account.getUserName());
			ps.executeUpdate();// 执行SQL语句
			// System.out.println(account.getPassword());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			ex = e;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			Util.close(ps, con, null);
		}
	}

	@Override
	public Account getAccount(Account account) {
		Account acc = null;
		try {
			con = Util.getCon();
			ps = (PreparedStatement) con.prepareStatement("SELECT password FROM users WHERE userName = ?;");
			ps.setString(1, account.getUserName());
			ResultSet rs = ps.executeQuery();
			acc = new Account(account.getUserName(), account.getPassword());
			if (rs.next()) {
				acc = new Account(account.getUserName(), rs.getString(1));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			ex = e;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			Util.close(ps, con, null);
		}
		return acc;
	}
}
