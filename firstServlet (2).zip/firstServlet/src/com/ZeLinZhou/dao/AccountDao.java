package com.ZeLinZhou.dao;

import com.ZeLinZhou.model.Account;

/**
 * 确认用户是否存在、新增用户与取得用户数据
 * 
 * @author Machenike
 *
 */
public interface AccountDao {
	void addAccount(Account account) throws Exception;

	Account getAccount(Account account);
}
