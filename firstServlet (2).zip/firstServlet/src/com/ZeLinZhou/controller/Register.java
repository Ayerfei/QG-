package com.ZeLinZhou.controller;

import com.ZeLinZhou.dao.impl.AccountDaoImpl;
import com.ZeLinZhou.model.Account;
import com.ZeLinZhou.util.*;

import java.io.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Register
 */
@WebServlet("/register.do")
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;
	// private final String SUCCESS_VIEW = "success.jsp";
	// private final String ERROR_VIEW = "../register.jsp";

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Register() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @throws IOException
	 * @throws ServletException
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath());
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		// String confirmedPasswd = request.getParameter("rePassword");//密码确认，再输一遍
		AccountDaoImpl add = new AccountDaoImpl();
		if (username != null) {
			response.getWriter().println(
					"<script> type='text/javascript'  >window.alert('ERROR!');window.location.href='./html/register.html'; </script>");
		}
		try {
			add.addAccount(new Account(username, password));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (username != null) {
			response.getWriter().println(
					"<script> type='text/javascript'  >window.alert('ERROR!');window.location.href='./html/register.html'; </script>");
		}
		if (password == null) {
			response.getWriter().println(
					"<script> type='text/javascript'  >window.alert('ERROR!');window.location.href='./html/register.html'; </script>");

		}
		/*
		 * CheckImpl check = new CheckImpl(); try { if(check.isInvalidUserName(user))
		 * {//判断注册时用户名是否已存在，或不符合格式 errors.add("用户名称为空或已存在");
		 * 
		 * } else { AccountDaoImpl add = new AccountDaoImpl();
		 * System.out.println(user.getUserName());
		 * System.out.println(user.getPassword()); add.addAccount(user); Account acc =
		 * add.getAccount(user); //System.out.println(acc.getUserName());
		 * //System.out.println(acc.getPassword()); response.getWriter().println(
		 * "<script> type='text/javascript'  >window.alert('SUCCESS!');window.location.href='./html/register.html'; </script>"
		 * ); } } catch (Exception e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); }
		 */
		/*
		 * if(check.isInvalidPassword(new Account(null, password), confirmedPasswd)) {
		 * errors.add("请确认密码符合格式并再次确认密码"); } else { AccountDaoImpl user = new
		 * AccountDaoImpl(); user.addAccount(new Account(userName, password)); }
		 */

		// String resultPage = "ERROR_VIEW";
		/*
		 * if(!errors.isEmpty()) { request.setAttribute("errors", errors);
		 * System.out.println("Error3"); } else { //resultPage = SUCCESS_VIEW;//注册成功跳转页面
		 * AccountDaoImpl addUser = new AccountDaoImpl(); addUser.addAccount(new
		 * Account(userName, password));//注册成功添加用户 }
		 */
		doGet(request, response);
		/*
		 * response.getWriter().println(
		 * "<script> type='text/javascript'>window.alert('SUCCESS OR ERROR!');window.location.href='./html/login.html';</script>"
		 * );
		 */
	}
}
